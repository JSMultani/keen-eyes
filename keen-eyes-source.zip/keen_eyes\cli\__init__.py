"""Keen Eyes CLI."""

